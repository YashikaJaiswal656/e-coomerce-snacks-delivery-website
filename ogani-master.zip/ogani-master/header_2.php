<!doctype html>
<html lang="en">
    <head>
        <title>Title</title>
        <!-- Required meta tags -->
        <meta charset="utf-8" />
        <meta
            name="viewport"
            content="width=device-width, initial-scale=1, shrink-to-fit=no"
        />
<style>
    .f{
        
        height: 50px;
        width: 100%;
        display: flex !important;
        justify-content:space-between !important;
        align-items:center;
    }
</style>
        <!-- Bootstrap CSS v5.2.1 -->
        <link
            href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
            rel="stylesheet"
            integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"
            crossorigin="anonymous"
        />
    </head>

    <body>
        
        <nav
            class="navbar navbar-expand-sm navbar-light  "
        >
            <div class="container   " >
                
                <a class="navbar-brand text-dark" href="#">Navbar</a>
                
                <div class="collapse navbar-collapse" id="collapsibleNavId">
                    <ul class="navbar-nav ms-auto mt-2 mt-lg-0">
                        <li class="nav-item dropdown">
                            <a
                                class="nav-link dropdown-toggle text-dark"
                                href="#"
                                id="dropdownId"
                                data-bs-toggle="dropdown"
                                aria-haspopup="true"
                                aria-expanded="false"
                                >YASHIKA</a
                            >
                            <div
                                class="dropdown-menu text-dark"
                                aria-labelledby="dropdownId"
                            >
                                <a class="dropdown-item" href="#"
                                    >CREATE CAT</a
                                >
                                <a class="dropdown-item" href="#"
                                    >LOGOUT</a
                                >
                            </div>
                        </li>
                    </ul>
                    
                </div>
            
                
               </div>
        </nav>
        
    
    <div class="container-fluid">
        <div class="row ">
            <div class="col-lg-2  text-dark">
            <div id="accordion">

<div class="card mt-3">
  <div class="card-header " style="background-color:white;">
  <a href="cat_1.php" class="text-dark collapsed btn">Create Cat</a>
  </div>
  </div>
  <div class="card mt-3">
  <div class="card-header" style="background-color:white;">
  <a href="Home_1.php" class="text-dark collapsed btn">Insert Data</a>
  </div>

</div>



<div class="card mt-3">
  <div class="card-header" style="background-color:white;">
    <a class="collapsed btn text-dark" href="delete_1.php">
     Delete
    </a>
  </div>

</div>

<div class="card mt-3">
  <div class="card-header" style="background-color:white;">
    <a class="collapsed btn text-dark"  href="index.php">
     Webpage
    </a>
  </div>

</div>

</div>


            </div>
        
    
    
    